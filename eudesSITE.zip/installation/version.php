<?php
// Protect from unauthorized access
defined('_JEXEC') or die('Restricted Access');

define('AKEEBA_PRO', '0');
define('AKEEBA_VERSION', '3.2.6');
define('AKEEBA_DATE', '2011-04-09');