var tagAlvo = new Array('p'); //pega todas as tags p//
 
// Especificando os possíveis tamanhos de fontes, poderia ser: x-small, small...
var tamanhos = new Array( '9px','10px','11px','12px','13px','14px','15px' );
var tamanhoInicial = 3;
 
function mudaTamanho( idAlvo,acao ){
  if (!document.getElementById) return
  var selecionados = null,tamanho = tamanhoInicial,i,j,tagsAlvo;
  tamanho += acao;
  if ( tamanho < 0 ) tamanho = 0;
  if ( tamanho > 6 ) tamanho = 6;
  tamanhoInicial = tamanho;
  if ( !( selecionados = document.getElementById( idAlvo ) ) ) selecionados = document.getElementsByTagName( idAlvo )[ 0 ];
  
  selecionados.style.fontSize = tamanhos[ tamanho ];
  
  for ( i = 0; i < tagAlvo.length; i++ ){
    tagsAlvo = selecionados.getElementsByTagName( tagAlvo[ i ] );
    for ( j = 0; j < tagsAlvo.length; j++ ) tagsAlvo[ j ].style.fontSize = tamanhos[ tamanho ];
  }
}

/* - geral.js - */
GOV_Events={};GOV_Events.add=function(obj,type,handler,cap){cap=cap||false;if(obj.addEventListener){obj.addEventListener(type,handler,cap)}else{obj.attachEvent("on"+type,handler)}}
GOV_Events.remove=function(obj,type,handler,cap){cap=cap||false;if(obj.removeEventListener){obj.removeEventListener(type,handler,cap)}else{obj.detachEvent("on"+type,handler)}}
function PS_resizeFonts(){if(document.getElementById("content")){
function PS_setSize(obj,size){var arrObj=document.getElementById("content").getElementsByTagName(obj);for(var i=0;i<arrObj.length;i++) arrObj[i].style.fontSize=size+"px"}
document.getElementById("content").style.fontSize=tam[0]+"px";PS_setSize("p",tam[0]);PS_setSize("dt",tam[0]);PS_setSize("dd",tam[0]);PS_setSize("li",tam[0])}}
var tam=[11,16,14,12,11,10,9];
function PS_increaseSize(type){for(var i=0;i<tam.length;i++)(type=="mais")?tam[i]++:tam[i]--}

function PS_changeFont(type){(type=="mais")?PS_increaseSize("mais"):PS_increaseSize("menos");PS_resizeFonts()}
$(document).ready(function(){$("#links_rapidos select").change(function(){location.href=this.value});$("#list_orgaos #btn_ok").click(function(){location.href=document.getElementById("list_orgaosEstados").value});$(".desc_noticia li:odd").css("background-color","#e9e9e9");var data=new Date();var dia_semana=data.getDay();var semana=new Array(6);semana[0]='Domingo';semana[1]='Segunda-Feira';semana[2]='Terça-Feira';semana[3]='Quarta-Feira';semana[4]='Quinta-Feira';semana[5]='Sexta-Feira';semana[6]='Sábado';var dia=data.getDate();var mes=data.getMonth();var ano=data.getFullYear();document.getElementById("data").innerHTML=dia+"/"+(mes+1)+"/"+ano+", "+semana[dia_semana]});

function showMap(){$("body").prepend('<div id="divMapa"><h4><a href="javascript:void(0);" onclick="hideMap();">Fechar</a></h4><iframe style="float:left;" src="map.html" width="515" height="470" scrolling="no" frameborder="0"></iframe><img src="fotoPredio.jpg" /><img src="logoMapa.jpg" /><br clear="all" /></div><div id="overlay"></div>')}
function hideMap(){$("#divMapa").remove();$("#overlay").remove()}


