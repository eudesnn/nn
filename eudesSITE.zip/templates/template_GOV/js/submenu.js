//Script para habilitar o li:hover no IE6
//Funciona apenas para 2 subn�veis
//� muito imporante que os par�metros do m�dulo estejam corretamente ajustados

//Fun��es de MouseOver e MouseOut
Over = function()
{
	this.className+=" over";
}
Out = function()
{
	this.className=this.className.replace(" over", "");
}

//Loop para verificar os n�s onde � preciso usar o li:hover
startList = function()
{
	if (document.all&&document.getElementById)
	{
		//n�vel ROOT
		navRoot = document.getElementById("menulist_root");
		for (i=0; i < navRoot.childNodes.length; i++)
		{
			node = navRoot.childNodes[i];
			if (node.nodeName=="LI")
			{
				node.onmouseover=Over;				
				node.onmouseout=Out;
			}
			nomeUL = "menulist_"+[i];
			navSub = document.getElementById(nomeUL);
			if (navSub != undefined)
			{
				//primeiro subn�vel
				for (p=0; p < navSub.childNodes.length; p++)
				{
					subnode = navSub.childNodes[p];
					if (subnode.nodeName=="LI")
					{
						subnode.onmouseover=Over;				
						subnode.onmouseout=Out;
					}
					nomeULSub = "menulist_"+[i]+"_"+[p+1];
					navSub2 = document.getElementById(nomeULSub);
					if (navSub2 != undefined)
					{
						//segundo subn�vel
						for (h=0; h < navSub2.childNodes.length; h++)
						{
						subnode2 = navSub2.childNodes[h];
							if (subnode2.nodeName=="LI")
							{
								subnode2.onmouseover=Over;				
								subnode2.onmouseout=Out;
							}
						}
					}					
				}
			}
		}
	}
}
window.onload=startList;