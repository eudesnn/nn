/*// C�DIGO DO REDIRECIONAMENTO

// Vari�veis de configura��o
var GOVCE_SECRETARIA = "PGE"; // TAMANHO M�XIMO: 15 caracteres
var GOVCE_ENDERECO = "www5.ceara.gov.br"; /// FIXO - N�O ALTERAR

// Verifica se o remetente � o Portal do Governo
var sRemetente = document.referrer;
if (sRemetente.indexOf(GOVCE_ENDERECO) > 0) {
	GerarCookie("GOVCERedir", "1", 1); 
}
else {
	// N�o veio do Governo.  Tenta obter Cookie de configuracao
	var sVerificaRedir = LerCookie("GOVCERedir");
	if (sVerificaRedir != "1") {
		GerarCookie("GOVCERedir", "1", 1);
		
		// Cria endere�o com todas as informa��es necess�rias (servidor, url, e poss�veis vari�veis query)
		var sUrlGovCe = location.href;
		
		// Redireciona para o portal do governo, passando o endere�o montado para poss�vel retorno
		location.href = "http://" + GOVCE_ENDERECO + "?secretaria=" + GOVCE_SECRETARIA + "&endereco=" + sUrlGovCe;
	}
}

// Fun��o para criar o cookie.
// Para que o cookie seja destru�do quando o browser for fechado, basta passar 0 no parametro lngDias.
function GerarCookie(strCookie, strValor, lngDias)
{
    var dtmData = new Date();

    if(lngDias)
    {
        dtmData.setTime(dtmData.getTime() + (lngDias * 10 * 60 * 60 * 1000));
        var strExpires = "; expires=" + dtmData.toGMTString();
    }
    else
    {
        var strExpires = "";
    }
	
    document.cookie = strCookie + "=" + strValor + strExpires + "; path=/";
}

// Fun��o para ler o cookie.
function LerCookie(strCookie)
{
    var strNomeIgual = strCookie + "=";
    var arrCookies = document.cookie.split(';');

    for(var i = 0; i < arrCookies.length; i++)
    {
        var strValorCookie = arrCookies[i];
        while(strValorCookie.charAt(0) == ' ')
        {
            strValorCookie = strValorCookie.substring(1, strValorCookie.length);
        }
        if(strValorCookie.indexOf(strNomeIgual) == 0)
        {
            return strValorCookie.substring(strNomeIgual.length, strValorCookie.length);
        }
    }
    return null;
}
*/