﻿<?php
	defined( '_JEXEC' ) or die( 'Restricted access' );
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN" "http://www.w3.org/TR/html4/strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"> 
<head>
	
	<jdoc:include type="head" />
	<meta http-equiv="Content-Type" content="text/html; <?php echo $charset; ?>" />
	<link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/template_GOV/css/main.css" type="text/css" />
	<link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/template_GOV/css/<?php if ( isset($_REQUEST['cssfile']) ){ echo $_REQUEST['cssfile']; } else { echo 'principal.css'; }?>" type="text/css" />

	<!--[if IE]>
		<link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/template_GOV/css/ie6.css" type="text/css" />
	<![endif]-->
	<!--[if IE 7]>
		<link rel="stylesheet" href="<?php echo $this->baseurl ?>/templates/template_GOV/css/ie76.css" type="text/css" />
	<![endif]-->

	<script type="text/javascript" src="<?php echo $this->baseurl?>/templates/template_GOV/js/data.js"></script>
	<?php JHTML::_('behavior.mootools'); ?>
	<?php JHTML::_('behavior.modal'); ?>
	<script type="text/javascript" src="<?php echo $this->baseurl?>/templates/template_GOV/js/submenu.js"></script>
	<script type="text/javascript" src="<?php echo $this->baseurl?>/templates/template_GOV/js/tamanho_fonte.js"></script>
		
</head>
<body>
<!--[if lt IE 7]>
	<div id="ie6aviso" style="z-index: 1000; width: 100%; height: 30px; background: #FFFFCC; border-bottom: solid 1px ; padding: 5px 0 5px 0; ">
	<div style="float: left; margin: 5px 0 0 5px;"><img src="templates/template_GOV/img/warn_ico.gif" /></div>
		<div style="margin-left: 10px; float: left; font-family: Arial, Helvetica, sans-serif; font-size: 12px;">
			<span style="font-weight: bold;"><span style="color: red;">AVISO:</span> seu navegador est&aacute; desatualizado.</span> Voc&ecirc; est&aacute; usando o Internet Explorer 6, 
			um antigo navegador que n&atilde;o possui suporte para os recursos dos sites atuais. Para uma melhor experi&ecirc;ncia com o nosso site 
			(e demais outros), por gentileza utilize navegadores populares como:
            <a style="text-decoration: underline; color: blue;" href="http://www.mozilla.com/">Firefox</a>, 
            <a style="text-decoration: underline; color: blue;" href="http://www.opera.com/download/">Opera</a>, 
            <a style="text-decoration: underline; color: blue;" href="http://www.apple.com/safari/download/">Safari</a>.
        </div>
    </div>
<![endif]-->
<!-- Início - DIV Geral -->
<div id="geral">

	<!-- Início - Cabeçalho -->
	<div id="header">
		<!-- Início -Barra Verde -->
		<div id="cab_topo">
        	<div id="cab_topo_data">
            	<script>dataAtual()</script>
            </div>
            <div id="cab_topo_elementos">
                <div id="cab_topo_govlink">
                    <a href="http://www.ceara.gov.br" alt="Acesse o Portal do Governo" title="" Acesse o Portal do Governo" target="_blank">
                        <img src="<?php echo $this->baseurl?>/templates/template_GOV/img/logo_gov_barra.jpg"/>
                    </a>
                </div>
                <div class="coluna"></div>
                <div id="cab_topo_menu">
            		<jdoc:include type="modules" name="top2" />
                </div>
                <div class="coluna"></div>
                <div id="cab_topo_busca">
            		<jdoc:include type="modules" name="top" />
                </div>
            </div>
        </div>
		<!-- Fim - Barra Verde -->
	
		<!-- Início - Barra de identificação Órgão -->
		<div id="middle_header">
			<!-- Logotipo Órgão -->
			<!-- Imagem waves -->
			<div id="logo_identidade"><a href="<?php echo $this->baseurl ?>"><img src="<?php echo $this->baseurl?>/templates/template_GOV/img/logo.png"></a>
			
			</div>
			
			<!-- You can place inside here the logo of your secretary -->
			<div id="top_waves"></div>
		</div>
				<!-- Fim - Barra de Identificação Órgão -->
		<?php if ($this->countModules('hornav')){ ?>
			
            <!-- Início - Menu de Categorias -->
			<div id="bottom_header_categorias" >
				<jdoc:include type="modules" name="hornav" />
				<div id="atalho_home">
					<div id="link_rss">
						<jdoc:include type="modules" name="syndicate" />
						<a href="<?php echo $this->baseurl ."/index.php?option=com_ninjarsssyndicator&feed_id=1&format=raw"?>" target="_blank"></a>
					</div>
					<a  href="<?php echo $this->baseurl?>" title="Página Inicial" class="link_home" ></a>
					<a href="http://sou.cge.ce.gov.br/publico/Inicial.aspx" target="_blank" title="Contato" class="link_mail" ></a>
					<a href="<?php echo $this->baseurl .'/index.php/mapa-do-site' ?>" title="Mapa do Site" class="link_map" ></a>
				</div>
			</div>
			<!-- Fim - Menu de Categorias -->			
		
		<?php } else { ?>
		
		<!-- Fim - Menu de Categorias -->
		
		<!-- Início - Menu simples - Sem categorias -->
		<!-- Oculto por default -->
		<!-- Para ativar 'display: block;' e o de categorias 'display:none;' -->
		<div id="bottom_header_simples">
			<div id="atalho_home">
				<div id="link_rss">
					<jdoc:include type="modules" name="syndicate" />
					<a href="<?php echo $this->baseurl ."/index.php?option=com_ninjarsssyndicator&feed_id=1&format=raw"?>" target="_blank"></a>
				</div>
				<a  href="<?php echo $this->baseurl?>" title="Página Inicial" class="link_home" ></a>
				<a href="http://sou.cge.ce.gov.br/publico/Inicial.aspx" target="_blank" title="Contato" class="link_mail" ></a>
				<a href="<?php echo $this->baseurl .'/index.php/mapa-do-site' ?>" title="Mapa do Site" class="link_map" ></a>
			</div>
		</div>
		<!-- Fim - Menu simples - Sem categorias -->
		
		<?php } ?>

		
	</div>
	<!-- Fim - Cabeçalho -->

	<!-- Início - Conteúdo Central -->
	<div id="corpo">
		<!-- Início - Painel Esquerdo -->
		<div id="left_side">
			<!-- Início - Menu Contextual -->
			<div id="menu_esquerda">
				<!-- Canto Arredondado -->
				<div id="round_corner_left_menu"></div>	
				<div class="links_context">
					<jdoc:include type="modules" name="left"/>
				</div>
			</div>
			<!-- Fim - Menu Contextual -->
			
			<!-- Início - Vinculadas -->
			<div id="vinculadas">				
				<h2 class="tema"><b>Secretarias e Órgãos</b></h2>
				<jdoc:include type="modules" name="user3" />				
			</div>
			<!-- Fim - Vinculadas -->

			<div id="telefones_uteis">				
				<h2 class="tema"><b>Telefones úteis</b></h2>
				<jdoc:include type="modules" name="advert2" />
			</div>
			
			<div id="midias_sociais">
				<h2 class="tema"><b>Redes Sociais</b></h2>
				<div id="links_midias">
					<jdoc:include type="modules" name="advert3" />
				</div>
			</div>
		</div>
		<!-- Fim - Painel Esquerdo -->
	
		<!-- Início - Conteúdo do Site -->
		<div id="content">
			<jdoc:include type="modules" name="pathway" />
			<jdoc:include type="modules" name="barra" />
			<jdoc:include type="component" />
		
			<!-- Fim - Cabeçalho página interna -->
			
			<!-- Início - Destaque -->
			<div id="destaque">
				<jdoc:include type="modules" name="user1" />				
			</div>
			<!-- Fim - Destaque -->		
			
			<!-- Início - Últimas Notícias -->
			<div id="noticias">		
				<jdoc:include type="modules" name="user4" />					
			</div>
			<!-- Fim - Notícias -->
			
			
			<jdoc:include type="modules" name="user8" />
		</div>
		<!-- Fim - Conteúdo do Site -->
	
		<!-- Início - Painel Direito -->
		<div id="right_side">
			<!-- Início - Menu de Serviços -->
			<div id="menu_direita">
				<!-- Canto arredondado -->
				<div id="round_corner_right_menu"></div>
				<div id="servicos" >
					<h2 class="tema"><b>Serviços</b></h2>				
				</div>				
				<div class="links_services">
					<jdoc:include type="modules" name="right" />
				</div>
			</div>
			<!-- Fim - Menu de Serviços -->
			
			<!-- Início - Banner rotativo -->
			<div id="banner_rotativo" ><jdoc:include type="modules" name="banner" /></div>
			<!-- Fim - Banner rotativo -->
			
            <!-- Início - Calendário -->	
			<div id="calendario" >
            	<h2 class="tema"><b>Calendário</b></h2>
            	<jdoc:include type="modules" name="user2" />
            </div>
            <!-- Fim - Calendário -->
			 				
		</div>
		<!-- Fim - Painel Direito -->
	</div>
	<!-- Fim - Conteúdo Central -->

	<!-- Início - Rodapé -->
	<div id="footer" >
		<!-- Imagem waves -->
		<div id="footer_ondas">
			<!-- Localização Órgão -->
			<p>

                CEP: 60.824.140  - <a class="modal" rel="{handler: 'iframe', size: {x: 770, y: 450}}" href="<?php echo $this->baseurl ?>/index.php?option=com_content&id=43386&tmpl=component&task=preview"><b>Ver localização no mapa</b></a> Fone: (88)99765-2333  |Rua São Benedito, 188 A - São Miguel, Juazeiro do Norte - CE, 63010-545<br />
			   Copyright © 2018 A Herbalife é associada à ABEVD - Associação Brasileira das Empresas de Vendas Diretas Herbalife Nenhuma reprodução total ou parcial pode ser feita sem autorização escrita. Todos os direitos reservados. Todas marcas registradas e imagens de produtos exibidas neste site são de propriedade da Herbalife International, Inc., salvo indicação em contrário.

</p>
		
		</div>
	</div>
	<!-- Fim - Rodapé -->
</div>
<!-- Fim - DIV Geral -->
</body>
</html>